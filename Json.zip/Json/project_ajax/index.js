
var url = "http://kratie.pnc.lan/laura.hennequin/ssl/project/messages.php";

function getMessage() {
    $("#body").addClass('loading');
    fetch(url).then(function(response) {
        if(!response.ok) {
            document.getElementById('content').innerHTML = "Something wrong with data...";
        } else {
            response.json().then(function(arr) {
                console.log(arr);
                var output = "<table class='table table-borderless table-hover'>";
                for(let i = 0; i < arr.length; i++) {
                    output += "<tr><td>" + arr[i].user + "</td>";
                    output += "<td>" + arr[i].message + "</td></tr>";
                }
                output += '</table>';
                document.getElementById('card-body').innerHTML = output;
            })
    
        }
    }, function(error) {
        document.getElementById('content').innerHTML = "Data is not found!";
    })
}

function sendMessage() {
    $("#body").addClass('loading');
    var user = $('#user').val();
    var message = $('#message').val();
    $.ajax({
        method: 'post',
        url: url,
        data: {"user":user, "message":message}
    })
    .done(getMessage)
    .fail(errorMessage);
}

 function errorMessage(error) {
     $("#body").removeClass('loading');
     $("#content").html('Sorry, you are an error: ' + 
         error.statusText + " (" + error.status + ")").css('color','red');
 } 

 $(document).ready(function() {
     getMessage();
     setInterval(function(){
         getMessage();
     }, 3000);
 })
